# Ghost + Nuxt 3 + Vercel ヘッドレス新聞サイト

Ghost(CMS/編集部) + Nuxt 3(配信/レンダリング) + Vercel(CDN/デプロイ) による
ヘッドレス新聞サイトのデータ層実装(Phase 1)。

## 設計の要点

- **記事内容**: Ghost Content APIで管理(タグはあくまで分類用途に限定)
- **紙面構成(号・面・記事の順序)**: `data/issues/*.json` としてGit管理
- **レンダリング**: Nuxt 3が両者をマージして表示

記事の公開経路(Ghost → Webhook → キャッシュ更新)と
プログラム変更経路(GitHub → Vercel Build)を完全に分離する設計。

## ディレクトリ構成

```
types/issue.ts              # Issue関連の型定義
lib/validateIssue.ts        # issues.jsonのバリデーション
lib/validateIssue.test.ts
lib/getIssue.ts             # issues.jsonとGhostデータのマージ処理
lib/getIssue.test.ts
lib/ghostClient.ts          # Ghost Content APIクライアント
lib/ghostClient.test.ts
server/api/issue/[id].get.ts  # Nuxt server API(号取得エンドポイント)
```

## issues.json スキーマ

```json
{
  "id": "2026-08",
  "title": "2026年8月号",
  "publishedAt": "2026-08-27",
  "pages": {
    "1": [
      { "type": "article", "article": "hello-ghost", "layout": "lead" },
      { "type": "article", "article": "second-post", "layout": "column" }
    ],
    "2": [
      { "type": "article", "article": "third-post", "layout": "small" }
    ]
  }
}
```

- `article` は Ghost の slug で統一
- `pages` のキーは 1始まりの非ゼロ埋め文字列("1", "2", "10")。疎らな面番号も可
- `type` は `article` / `ad` / `index`(ad, index は Phase 1 では構造のみ許容、描画は未実装)
- `layout` は `lead` / `column` / `small`(article必須)
- ファイル名(`2026-08.json`)と `id` フィールドの一致を起動時に検証

## 実装済み(Phase 1: データ層)

- [x] `types/issue.ts` — 型定義(ArticleItem / FutureItem分離)
- [x] `validateIssue.ts` — スキーマ検証 + テスト一式
- [x] `getIssue.ts` — マージロジック(slug重複排除・順序維持・欠損記事は警告ログのみ)+ テスト一式
- [x] `ghostClient.ts` — Ghost Content API接続アダプター + テスト一式
- [x] `server/api/issue/[id].get.ts` — Nuxt server API(YYYY-MM形式検証、404/500/400切り分け)

## 未着手

- [ ] Vercel上でのISR/routeRules実挙動確認
- [ ] Ghost Webhook実装(post.published/updated → invalidate)
- [ ] `/issue/[id]` ページ・面ページのレンダリング(layout別コンポーネント)

## 先送り事項

- Ghost filter URLの長さ制限対応(記事数が大幅に増えた場合のslugチャンク分割)
  → Phase 1の規模(1号あたり10〜30記事程度)では対応不要と判断

## テスト実行

```bash
npm install
npx vitest run
```
